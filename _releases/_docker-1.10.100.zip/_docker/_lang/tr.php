<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#	 ____  _   _ ___ _____ _____ _____ ___ ____  _   _ 
#	/ ___|| | | |_ _|_   _| ____|  ___|_ _/ ___|| | | |
#	\___ \| | | || |  | | |  _| | |_   | |\___ \| |_| |
#	 ___) | |_| || |  | | | |___|  _|  | | ___) |  _  |
#	|____/ \___/|___| |_| |_____|_|   |___|____/|_| |_|                       
#									  __       _  _  _  _ __    __ 
#									 / /(\/\/)( \( \( \( \\ \  / / 
#									( (  )  (  ) )) )) )) )) )( (  
#									 \_\(/\/\)(_/(_/(_/(_//_/  \_\ 
#
#	Copyright (C) 2026 Jan Maurice Dahlmanns [Bugfish]
#	This file is part of the core library and is NOT included
#	in any sublicense or third-party license agreements.
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
##########################################################################################
## Store Versioning Translations
##########################################################################################
store_version_name=Şablon: Docker Modülü
store_version_description=Yöneticimiz için Docker Server Manager Eklentisi örneği, özellikle Geliştiriciler için. Docker Modülleri hakkında daha fazla bilgiye Suitefish Belgeleri ve depo içindeki ilgili Readme.md dosyalarından ulaşabilirsiniz!

##########################################################################################
## Substitution Explanation Translations
##########################################################################################
var_select_key=Bu, otomatik oluşturulan form aracılığıyla .env dosyasında tekli seçim değerinin değiştirilmesine bir örnektir.
var_select_key_v1=Bu, ilk seçim değeridir.
var_select_key_v2=Bu, ikinci seçim değeridir.
var_select_key_v3=Bu, üçüncü seçim değeridir.
var_string_key=Bu, otomatik oluşturulan form aracılığıyla .env dosyasında dize değeri değiştirilmesine bir örnektir.
var_numeric_key=Bu, otomatik oluşturulan form aracılığıyla .env dosyasında sayısal değer değiştirilmesine bir örnektir.
var_port_key=Bu, otomatik oluşturulan form aracılığıyla .env dosyasında bağlantı noktası değerinin değiştirilmesine bir örnektir.
var_checkbox_key=Bu, otomatik oluşturulan form aracılığıyla .env dosyasında onay kutusu değerinin değiştirilmesine bir örnektir.

##########################################################################################
## Command Translations
##########################################################################################
command_dir=Komut 1
command_dir_descr=Sistemde basit bir komut çalıştır
command_cat=Komut 2
command_cat_descr=Sistemde basit bir dosya göster